import java.util.*

fun Fibo(n : Int):Int{
    var fibo_n : Int
    if(n<=1){
        fibo_n = n
    }else {
        fibo_n = Fibo(n-2)+Fibo(n-1)
    }
    return fibo_n
}
fun main(args: Array<String>) {
    val cin = Scanner(System.`in`)
    print("input n to generate Fibonacci series(0~n) :")
    val n = cin.nextInt()
    var fibo_i : Int
    for(i in 0..n){
        fibo_i = Fibo(i)
        print("Fibo(%3d) = %20d\n".format(i, fibo_i))
    }
    cin.close()
}