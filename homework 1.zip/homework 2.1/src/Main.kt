import java.util.Scanner
import kotlin.math.*


fun printArray(arr:IntArray){
    val size = arr.size
    for(i in 0..size-1){
        print("%3d".format(arr[i]))
    }
    println()
}

fun insertionSort(arr:IntArray){
    val size = arr.size
    for(i in 1..size-1){
        val key = arr[i]
        var j = i
        while(j>0){
            if(arr[j-1]<= key)
                break
            arr[j] = arr[j-1]
            j--
        }
        arr[j] = key
    }
}

fun findVar(arr:IntArray):Double{
    val average = arr.average()
    var variance = 0.0
    val size = arr.size
    for( i in 0..size-1){
        variance += (arr[i]-average).pow(2)
    }
    return variance / arr.size

}

fun main(args : Array<String>){
    val intArray = IntArray(10)
    val cin = Scanner(System.`in`)
    var data : Int
    print("Enter 10 integers : ")
    for(i in 0..9){
        data = cin.nextInt()
        intArray[i] = data
    }
    print("Input data before sorting: ")
    printArray(intArray)
    insertionSort(intArray)
    print("Input data after sorting: ")
    printArray(intArray)

    print("In reverse order : ")
    for(i in 9 downTo 0){
        print("%3d".format(intArray[i]))
    }
    println()

    val max = intArray.maxOrNull()
    val min = intArray.minOrNull()
    val avr = intArray.average()
    var variance = findVar(intArray)
    val std = sqrt(variance)
    print("Statistics :Statistics of the array: min(%d), max(%d), avr(%.3f), var(%.3f), std(%.3f)".format(min,max,avr,variance,std))

}